María Fernanda González Chávez
313036367

PROCESO DIGITAL DE IMÁGENES

TO RUN THIS PROGRAM NEED TO BE INSTALED
PYTHON AND OPENVC

Here says how to install OpenVC on Ubuntu
https://www.pyimagesearch.com/2015/06/22/install-opencv-3-0-and-python-2-7-on-ubuntu/
